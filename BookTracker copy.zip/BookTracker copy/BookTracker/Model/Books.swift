//
//  Books.swift
//  BookTracker
//
//  Created by user265378 on 8/29/24.
//
import Foundation

struct Book: Identifiable, Decodable {
    var id: String { volumeInfo.title }
    let volumeInfo: VolumeInfo
}


struct VolumeInfo: Decodable {
    let title: String
    let authors: [String]
    let description: String
    let publisher: String?
    let pageCount: Int?
    let language: String?
    let thumbnail: String?

    
    init(
        title: String,
        authors: [String],
        description: String,
        publisher: String? = nil,
        pageCount: Int? = nil,
        language: String? = nil,
        thumbnail: String? = nil
    ) {
        self.title = title
        self.authors = authors
        self.description = description
        self.publisher = publisher
        self.pageCount = pageCount
        self.language = language
        self.thumbnail = thumbnail
    }

    enum CodingKeys: String, CodingKey {
        case title
        case authors
        case description
        case publisher
        case pageCount
        case language
        case imageLinks
    }

    enum ImageLinksKeys: String, CodingKey {
        case thumbnail
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        title = try container.decode(String.self, forKey: .title)
        authors = try container.decodeIfPresent([String].self, forKey: .authors) ?? []
        description = try container.decodeIfPresent(String.self, forKey: .description) ?? "No description available"
        publisher = try container.decodeIfPresent(String.self, forKey: .publisher)
        pageCount = try container.decodeIfPresent(Int.self, forKey: .pageCount)
        language = try container.decodeIfPresent(String.self, forKey: .language)

        if let imageLinksContainer = try? container.nestedContainer(keyedBy: ImageLinksKeys.self, forKey: .imageLinks) {
            thumbnail = try imageLinksContainer.decodeIfPresent(String.self, forKey: .thumbnail)
        } else {
            thumbnail = nil
        }
    }
}


struct GoogleBooksResponse: Decodable {
    let items: [Book]
}
