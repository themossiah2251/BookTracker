//
//  BookTrackerApp.swift
//  BookTracker
//
//  Created by user265378 on 8/28/24.
//

import SwiftUI
import FirebaseCore

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
      
      FirebaseApp.configure()
    return true
  }
}

@main
struct YourApp: App {
    @StateObject private var session = SessionStore()
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @State private var books: [Book] = []
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                if session.currentUser != nil {
                    MainView()
                }else{
                    ContentView(books: $books)
                    
                }
            }
            .environmentObject(session)
        }
    }
}
