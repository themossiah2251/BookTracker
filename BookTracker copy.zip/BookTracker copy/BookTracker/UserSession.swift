//
//  UserSession.swift
//  BookTracker
//
//  Created by user265378 on 8/29/24.
//
import SwiftUI
import FirebaseAuth

@MainActor
class SessionStore: ObservableObject {
    @Published var currentUser: User?

    init() {
        self.currentUser = Auth.auth().currentUser
    }

    func signIn(email: String, password: String, completion: @escaping (Bool, String?) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(false, error.localizedDescription)
            } else {
                self.currentUser = result?.user
                completion(true, nil)
            }
        }
    }

    func signUp(email: String, password: String, completion: @escaping (Bool, String?) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(false, error.localizedDescription)
            } else {
                self.currentUser = result?.user
                completion(true, nil)
            }
        }
    }

    func signOut() {
        do {
            try Auth.auth().signOut()
            self.currentUser = nil
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
    }
}
