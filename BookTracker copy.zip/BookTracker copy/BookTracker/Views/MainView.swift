//
//  MainView.swift
//  BookTracker
//
//  Created by user265378 on 9/1/24.
//

import SwiftUI
import MapKit

struct MainView: View {
    
    @State private var books: [Book] = []
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), // San Francisco as default
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    @State private var searchResults: [MKMapItem] = []
    
    var body: some View {
        TabView {
            HomeView(books: $books)
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            StoreLocatorSearchView()
                           .tabItem {
                               Image(systemName: "map.fill")
                               Text("Store Locator")
                           }
            BookListView(books: $books)
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("Books")
                }
            ProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
        }
    }
}

#Preview {
    MainView()
}
