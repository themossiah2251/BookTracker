//
//  HomeView.swift
//  BookTracker
//
//  Created by user265378 on 9/1/24.
//

import SwiftUI

struct HomeView: View {
    @Binding var books: [Book]
    @State private var searchText: String = ""
    @State private var searchResults: [Book] = []
    @State private var isLoading: Bool = false
    @State private var errorMessage: String? = nil
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Welcome! Come Make Reading Fun!")
                    .font(.largeTitle)
                    .multilineTextAlignment(.center)
                    .padding()
                
                
                HStack {
                    TextField("Search for books", text: $searchText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading)
                    
                    Button(action: {
                        fetchBooks(query: searchText)
                    }) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.blue)
                            .cornerRadius(8)
                    }
                    .padding(.trailing)
                }
                .padding(.top)
                
                if isLoading {
                    ProgressView("Searching...")
                        .progressViewStyle(CircularProgressViewStyle())
                        .padding()
                } else if !searchResults.isEmpty {
                    List(searchResults) { book in
                        HStack {
                            Text(book.volumeInfo.title)
                                .font(.headline)
                            
                            Spacer()
                            
                            Button(action: {
                                addBook(book)
                            }) {
                                Text("Add")
                                    .font(.caption)
                                    .padding(5)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(5)
                            }
                        }
                    }
                } else if !isLoading && searchResults.isEmpty {
                    Spacer()
                    Text("No books found. Try another search.")
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding()
                    Spacer()
                }
                
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .padding()
                }
                
                Spacer()
            }
            .navigationTitle("Home")
        }
    }
    
    private func fetchBooks(query: String) {
        isLoading = true
        searchResults = []
        errorMessage = nil

        let urlString = "https://www.googleapis.com/books/v1/volumes?q=\(query)&key=AIzaSyCod4tQ9U3HsBW_FkDOdJVeqROEg5r5QXU"
        guard let url = URL(string: urlString) else {
            isLoading = false
            errorMessage = "Invalid URL."
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
                if let error = error {
                    self.errorMessage = error.localizedDescription
                    return
                }

                guard let data = data else {
                    self.errorMessage = "No data received."
                    return
                }

                do {
                    let result = try JSONDecoder().decode(GoogleBooksResponse.self, from: data)
                    self.searchResults = result.items
                } catch {
                    self.errorMessage = "Failed to decode response."
                    print("Decoding error: \(error)")
                }
            }
        }.resume()
    }
    
    private func addBook(_ book: Book) {
        books.append(book)
    }
}

#Preview {
    HomeView(books: .constant([]))
}
