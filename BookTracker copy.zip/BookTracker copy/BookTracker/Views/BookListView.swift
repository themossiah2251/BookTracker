//
//  BookListView.swift
//  BookTracker
//
//  Created by user265378 on 8/29/24.
//
import SwiftUI

struct BookListView: View {
    @Binding var books: [Book]

    var body: some View {
        NavigationView {
            VStack {
                if books.isEmpty {
                    Spacer()
                    Text("No books added yet.")
                        .foregroundColor(.secondary)
                        .padding()
                    Spacer()
                } else {
                    List {
                        ForEach(books) { book in
                            HStack {
                                NavigationLink(destination: BookDetailView(book: book)) {
                                    HStack {
                                       
                                        if let thumbnail = book.volumeInfo.thumbnail,
                                           let url = URL(string: thumbnail) {
                                            AsyncImage(url: url) { phase in
                                                switch phase {
                                                case .empty:
                                                    ProgressView()
                                                        .frame(width: 50, height: 75)
                                                case .success(let image):
                                                    image.resizable()
                                                        .frame(width: 50, height: 75)
                                                case .failure:
                                                    Image("no-image")
                                                        .resizable()
                                                        .frame(width: 50, height: 75)
                                                @unknown default:
                                                    Image("no-image")
                                                        .resizable()
                                                        .frame(width: 50, height: 75)
                                                }
                                            }
                                        } else {
                                           
                                            Image("no-image")
                                                .resizable()
                                                .frame(width: 50, height: 75)
                                        }

                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(book.volumeInfo.title)
                                                .font(.headline)
                                            Text(book.volumeInfo.authors.joined(separator: ", "))
                                                .font(.subheadline)
                                                .foregroundColor(.secondary)
                                            Text(book.volumeInfo.description)
                                                .lineLimit(2)
                                                .font(.body)
                                        }

                                        Spacer()
                                    }
                                    .padding(.vertical, 5)
                                }

                                Spacer()

                                
                                Button(action: {
                                    removeBook(book: book)
                                }) {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                }
                                .buttonStyle(BorderlessButtonStyle())
                                .padding(.leading, 10)
                            }
                        }
                    }
                }
            }
            .navigationTitle("My Books")
        }
    }

    private func removeBook(book: Book) {
        if let index = books.firstIndex(where: { $0.id == book.id }) {
            books.remove(at: index)
        }
    }
}

#Preview {
    BookListView(books: .constant([]))
}
