//
//  ProfileView.swift
//  BookTracker
//
//  Created by user265378 on 9/1/24.
//

import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var session: SessionStore
    var body: some View {
        VStack {
            if let user = session.currentUser {
                Text("Welcome, \(user.email ?? "User")!")
                    .font(.title)
                    .padding()
                Button(action: {
                    session.signOut()
                }){
                    Text("Sign Out")
                        .foregroundColor(.red)
                }
                .padding()
            }else{
                Text("Not Logged In")
            }
            Spacer()
        }
        .navigationTitle("Profile")
       
    }
}

#Preview {
    ProfileView()
}
