//
//  LoginView.swift
//  BookTracker
//
//  Created by user265378 on 8/29/24.
//

import SwiftUI

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage: String?
    
    @EnvironmentObject var session: SessionStore
    
    var body: some View {
        VStack{
            TextField("Email",text:$email)
                .autocapitalization(.none)
                .keyboardType(.emailAddress)
                .padding()
            SecureField("Password",text: $password)
                .padding()
            if let errorMessage = errorMessage {
                Text(errorMessage).foregroundColor(.red)
            }
            Button("Login"){
                session.signIn(email:email,password:password){
                    success, error in
                    if !success{
                        self.errorMessage = error
                    }
                }
            }
            .padding()
            
            NavigationLink("Registration", destination: RegisterView())
                .padding(.top,20)
        }
        .padding()
        
    }
}

#Preview {
    LoginView()
}
