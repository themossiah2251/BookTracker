//
//  BookDetailView.swift
//  BookTracker
//
//  Created by user265378 on 8/29/24.
//

import SwiftUI

struct BookDetailView: View {
    let book: Book

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
           
            if let thumbnail = book.volumeInfo.thumbnail, let url = URL(string: thumbnail) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(maxWidth: .infinity, maxHeight: 250)
                    case .success(let image):
                        image.resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: 250)
                    case .failure:
                        Image("no-image")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: 250)
                    @unknown default:
                        Image("no-image")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: 250)
                    }
                }
            } else {
                Image("no-image")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 250)
            }
            
            
            Text(book.volumeInfo.title)
                .font(.largeTitle)
            
            Text("by \(book.volumeInfo.authors.joined(separator: ", "))")
                .font(.title2)
            
            Text(book.volumeInfo.description)
                .font(.body)
            
            Spacer()
        }
        .padding()
        .navigationTitle(book.volumeInfo.title)
    }
}

struct BookDetailView_Previews: PreviewProvider {
    static var previews: some View {
        let mockVolumeInfo = VolumeInfo(
            title: "Sample Book Title",
            authors: ["Author One", "Author Two"],
            description: "This is a sample description of the book.",
            publisher: "Sample Publisher",
            pageCount: 320,
            language: "en",
            thumbnail: "https://example.com/thumbnail.jpg"
        )
        let mockBook = Book(volumeInfo: mockVolumeInfo)
        
        BookDetailView(book: mockBook)
    }
}
