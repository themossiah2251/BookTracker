//
//  StoreLocatorView.swift
//  BookTracker
//
//  Created by user265378 on 9/4/24.
//
import SwiftUI
import MapKit


extension MKMapItem: Identifiable {
    public var id: UUID {
        return UUID()
    }
}
struct StoreLocatorSearchView: View {
    @State private var searchText: String = ""
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), 
        span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5)
    )
    @State private var searchResults: [MKMapItem] = []

    var body: some View {
        VStack {
            
            HStack {
                TextField("Search for bookstores...", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.leading)
                    .padding(.trailing)
                
                Button(action: {
                    performSearch(query: searchText)
                }) {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color.blue)
                        .cornerRadius(8)
                }
                .padding(.trailing)
            }
            .padding(.top, 20)
            
            
            Map(coordinateRegion: $region, annotationItems: searchResults) { result in
                MapMarker(coordinate: result.placemark.coordinate, tint: .blue)
            }
            .frame(height: 300)
            .cornerRadius(10)
            .padding(.horizontal)
            
            
            if searchResults.isEmpty {
                Text("No bookstores found")
                    .padding()
            } else {
                List(searchResults, id: \.self) { result in
                    VStack(alignment: .leading) {
                        Text(result.name ?? "Unknown Bookstore")
                            .font(.headline)
                        Text(result.placemark.title ?? "Address unavailable")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 5)
                }
            }

            Spacer()
        }
        .navigationTitle("Store Locator")
    }

   
    func performSearch(query: String) {
        guard !query.isEmpty else {
            print("Search query is empty")
            return
        }

        
        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = "bookstore"
        searchRequest.region = region

        let search = MKLocalSearch(request: searchRequest)
        search.start { response, error in
            if let error = error {
                print("Error searching for bookstores: \(error)")
                return
            }

            
            if let response = response {
                DispatchQueue.main.async {
                    searchResults = response.mapItems
                    if let firstItem = response.mapItems.first {
                      
                        region = MKCoordinateRegion(
                            center: firstItem.placemark.coordinate,
                            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
                        )
                    }
                }
            }
        }
    }
}

#Preview {
    StoreLocatorSearchView()
}
