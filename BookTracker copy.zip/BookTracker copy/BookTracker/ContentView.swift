//
//  ContentView.swift
//  BookTracker
//
//  Created by user265378 on 8/28/24.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var session: SessionStore
        @Binding var books: [Book]
    var body: some View {
        if session.currentUser != nil{
            BookListView(books: $books)
        }else{
            LoginView()
        }
    }
}

#Preview {
    ContentView(books: .constant([]))
}
